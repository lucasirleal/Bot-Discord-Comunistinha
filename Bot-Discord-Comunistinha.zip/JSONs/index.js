exports.ChannelID = require('./channelIDs.json');
exports.Configs = require('./configs.json');
exports.MuteTracker = require('./muteTracker.json');
exports.WarnTracker = require('./warnTracker.json');